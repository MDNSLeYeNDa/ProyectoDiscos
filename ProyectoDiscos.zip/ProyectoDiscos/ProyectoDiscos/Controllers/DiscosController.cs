﻿using ProyectoDiscos.DataAccessLayel;
using ProyectoDiscos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoDiscos.Controllers
{
    public class DiscosController : Controller
    {
        // GET: Discos
        public ActionResult Index()
        {
            List<Disco> disco;

            using (var context = new DiscosDAL())
            {
                disco = context.Discos.ToList();
            }
            return View(disco);
        }

        [HttpGet]
        public ActionResult CreateDisco()
        {
            return View();
        }


        [HttpPost]
        public ActionResult CreateDisco(Disco disco)
        {
            if (ModelState.IsValid)
            {
                using (var context = new DiscosDAL())
                {
                    context.Discos.Add(disco);
                    context.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            else
                return View();
        }
    }
}