﻿using ProyectoDiscos.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace ProyectoDiscos.Models
{
    public class Disco
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Disco()
        {
            this.DiscoTipoes = new HashSet<DiscoTipo>();
            this.Puntuacions = new HashSet<Puntuacion>();
        }

        [Key]
        public int IdDisco { get; set; }
        [Required(ErrorMessage = "Titulo requerido")]
        public string Titulo { get; set; }
        [Required(ErrorMessage = "Agno requerido")]
        public Nullable<double> Agno { get; set; }
        [Required(ErrorMessage = "IdInterprete requerido")]
        public Nullable<int> IdInterprete { get; set; }
        [Required(ErrorMessage = "IdDiscografica requerido")]
        public Nullable<int> IdDiscografica { get; set; }

        [ForeignKey("IdDiscografica")]
        public virtual Discografica Discografica { get; set; }
        [ForeignKey("IdInterprete")]
        public virtual Interprete Interprete { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DiscoTipo> DiscoTipoes { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Puntuacion> Puntuacions { get; set; }
    }
}