﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProyectoDiscos.Models
{
    public class Discografica
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Discografica()
        {
            this.Discoes = new HashSet<Disco>();
        }

        [Key]
        public int IdDiscografica { get; set; }
        public string Nombre { get; set; }
        public string CodPais { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Disco> Discoes { get; set; }
    }
}