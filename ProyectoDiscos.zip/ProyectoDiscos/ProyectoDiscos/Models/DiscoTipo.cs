﻿using ProyectoDiscos.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProyectoDiscos.Models
{
    public class DiscoTipo
    {
        [Key]
        public int Id { get; set; }
        public Nullable<int> IdDisco { get; set; }
        public Nullable<int> IdTipo { get; set; }

        public virtual Disco Disco { get; set; }
        public virtual Tipo Tipo { get; set; }
    }
}